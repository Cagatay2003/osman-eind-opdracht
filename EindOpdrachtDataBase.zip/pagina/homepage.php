<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welkom bij Loyal Rental's</title>
    <link rel="stylesheet" href="../CSS/beroepsproject.css"> <!-- Voeg hier indien nodig je eigen CSS-bestand toe -->
</head>
<body>
    <header>
        <nav>      
            <ul>
                <li><a href="../pagina/catalogus.php">Catalogus</a></li>
                <?php 
                session_start();

                include '../Database/loginclass.php';
                include '../Database/dbclass.php';
                $database = new Login(new Database());
                
                if (isset($_SESSION['email'])) {
                $rol = $database->KrijgGebruikerrolEmail($_SESSION['email']);

            if ($rol == 'Admin') {
                echo '<li><a href="admin_panel.php">Admin</a></li>';
                echo '<li><a href="loguit.php">Uitloggen</a></li>';
            } else if ($rol == 'Medewerker') {
                echo '<li><a href="medewerker_panel.php">Medewerker</a></li>';
                echo '<li><a href="loguit.php">Uitloggen</a></li>';
            } else if ($rol == 'Klant') {  
                echo '<li><a href="facaturen.php">Facturen</a></li>';
                echo '<li><a href="loguit.php">Uitloggen</a></li>';
            }
        } else {
            echo '<li><a href="facaturen.php">Facturen</a></li>';
            echo '<li><a href="../pagina/inloggen.php">Inloggen</a></li>';
        }
        ?>
            </ul>
        </nav>
    </header>

<section class="hero">
    <div class="hero-content">
        <h1>Welkom terug bij Loyal Rental's </h1>
        <h2 class="zwart">Ontdek onze nieuwste voertuigen en hoogwaardige services.</h2>
        <a href="../pagina/catalogus.php" class="cta-button">Bekijk Onze Voorraad</a>
    </div>
    <img src="../image/rs62.png" alt="Achtergrondafbeelding" class="hero-background">
</section>

<h2>Voorraad</h2>
<section class="voertuigen">
    <div class="voertuig">
        <img src="../image/rs62.png" alt="Auto 1">
        <div class="voertuig-details">
            <p><strong>Audi RS6</strong></p>
            <p>Een krachtige en stijlvolle auto met indrukwekkende functies. Perfect voor avontuurlijke ritten en comfortabele reizen.</p>
            <a href="../pagina/autocatologus.php" class="cta-button">Meer Details</a>
        </div>
    </div>

    <div class="voertuig">
        <img src="../image/m8.png" alt="Auto 2">
        <div class="voertuig-details">
            <p><strong>BMW M8</strong></p>
            <p>Een moderne en elegante auto met geavanceerde technologieën. Ideaal voor stadsritten en lange afstanden.</p>
            <a href="../rentcfcar/pagina/autocatologus.php" class="cta-button">Meer Details</a>
        </div>
    </div>

    <div class="voertuig">
        <img src="../image/m4.png" alt="Auto 3">
        <div class="voertuig-details">
            <p><strong>BMW M4</strong></p>
            <p>Een sportieve en dynamische auto met een opvallend ontwerp. Geniet van snelheid en comfort in deze geweldige keuze.</p>
            <a href="../rentcfcar/pagina/autocatologus.php" class="cta-button">Meer Details</a>
        </div>
    </div>
</section>


<section class="contact">
    <h2>Contacteer Ons</h2>
    <p>Heeft u vragen of wilt u langskomen? Neem contact met ons op.</p>
    <a href="contact.html" class="cta-button">Neem Contact Op</a>
</section>

<footer>
    <p>&copy; 2023 loyal Waggie's BV. Alle rechten voorbehouden.</p>
</footer>
</body>
</html>
