<?php 
include '../Database/dbclass.php';
include '../Database/catalogusclass.php';
$catalogus = new Catalogus(new Database());

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../CSS/beroepsproject.css">
    <title>Loyal Rental | Catalogus</title>
</head>
<body>
<header>
    <nav>      
        <ul>
            <li><a href="../pagina/homepage.php">Home</a></li>
            <li><a href="../pagina/catalogus.php">Catalogus</a></li>
            <li><a href="../pagina/inloggen.php">Login</a></li>
            <li><a href="../pagina/registreren.php">Registreren</a></li>
            <li><a href="../pagina/contact.php">Contact</a></li> 
        </ul>
    </nav>
</header>

<div class="autosectie">
<?php
include '../Database/loginclass.php';
$database = new Login(new Database());

$cars = $catalogus->selecteeralleautos();
if ($cars) {
        $rol = $database->KrijgGebruikerrolEmail($_SESSION['email']);

        foreach ($cars as $car) {
            $imageurl = "../image/" . $car['image'];
    
            echo "<div class='car-details'>";
            echo "<h2>{$car['automerk']} {$car['model']}</h2>";
            echo "<div class='image-container'>";
            echo "<img class='autoimage' src='{$imageurl}'>";
            echo "</div>";
            echo "<p>Bouwjaar: {$car['bouwjaar']}</p>";
            echo "<p>Kenteken: {$car['kenteken']}</p>";
            echo "<p>Prijs: {$car['prijs']}</p>";
           
    
            echo "<div class='addcarbutton-container'>";
    
            if ($rol == 'Admin' || $rol == 'medewerker') {
                $cars = $catalogus->selectalleautoadmin();
                echo "<a href='editcar.php?auto_id={$car['auto_id']}' class='add-car-button'>bewerken</a>";
                echo "<a href='beschikbaar.php?auto_id={$car['auto_id']}' class='add-car-button'>verwijder</a>";
            } else {
                $cars = $catalogus->selecteeralleautos();
                echo "<a href='reserveren.php?auto_id={$car['auto_id']}' class='add-car-button'>Reserveren   </a>";
            }
    
            echo "</div>";
            echo "</div>";
        }
    }

    ?>
</div>
</body>
</html>