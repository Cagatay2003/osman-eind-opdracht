<?php
include '../Database/dbclass.php';
include '../Database/loginclass.php';
$database = new Database();
$database = new Login(new Database());
 
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $voornaam = $_POST['voornaam'];
    $achternaam = $_POST['achternaam'];
    $geboortedatum = $_POST['geboortedatum'];
    $gebruikerrol = 'Klant';
    $adres = $_POST['adres'];
    $rijbewijsnummer = $_POST['rijbewijsnummer'];
    $telefoonnummer = $_POST['telefoonnummer'];
    $email = $_POST['email'];
   
    try {
        $database->voegUser($username, $password, $voornaam, $achternaam, $geboortedatum, $gebruikerrol, $adres, $rijbewijsnummer, $telefoonnummer, $email);
        header("Location: inloggen.php");
        exit();
    } catch (PDOException $e) {
        echo "Error inserting: " . $e->getMessage();
    }
}
 
?>

<!DOCTYPE html>
<html>
    <link rel="stylesheet" href="../CSS/regist.css">
<head>
    <title>Registratie</title>
</head>
<body>
    <h1>Registratie</h1>
    
    <form method="post">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Wachtwoord" required>
        <input type="text" name="voornaam" placeholder="Voornaam" required>
        <input type="text" name="achternaam" placeholder="Achternaam" required>
        <input type="date" name="geboortedatum" placeholder="Geboortedatum" required>
        <input type="text" name="adres" placeholder="Adres" required>
        <input type="text" name="rijbewijsnummer" placeholder="Rijbewijsnummer" required>
        <input type="tel" name="telefoonnummer" placeholder="Telefoonnummer" required>
        <input type="email" name="email" placeholder="Emailadres" required>
        
        <input type="submit" value="Registreren">
    </form>
</body>
</html>
