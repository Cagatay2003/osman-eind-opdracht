<?php
session_start();
include '../Database/dbclass.php';
include '../Database/loginclass.php';
$database = new Database();
$database = new Login(new Database());
 
try {
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = htmlspecialchars($_POST['email']);
    $user = $database->userLoginSysteem($email);
   
    if($user) {
        if ($user && password_verify($_POST['password'], $user['password'])) {
        $_SESSION['klant_id'] = $user['klant_id'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['gebruikerrol'] = $user['gebruikerrol'];
        header('Location: homepage.php?ingelogd');
        } else {
            echo "incorrect email or password";
        }
        } else {
            echo "incorrect email or password";
        }
    }
} catch (\Exception $e) {
   echo $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loyal Waggie's Autoverhuur</title>
    <link rel="stylesheet" href="../CSS/login.css">

</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="../pagina/homepage.php">Home</a></li>
                <li><a href="../pagina/catalogus.php">Gebruikte Auto's</a></li>
                <li><a href="../pagina/register.php">Registreren</a></li>
                <li><a href="contact.html">Contact</a></li>
            </ul>
        </nav>
    </header>
    <div class="container">
        <div class="form">
            <h2>Inloggen</h2>
            <form method="post">
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Wachtwoord:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit">Inloggen</button>
            </form>
            <div class="forgot-password">
                <a href="wwvergeten.html">Wachtwoord vergeten?</a>
            </div>
        </div>

</body>
</html>


