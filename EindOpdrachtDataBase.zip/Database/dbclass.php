<?php 

class Database {
    public $pdo;
    
    public function __construct($database = 'rentcfcar', $user = 'root', $host = 'localhost:3307', $pass = '') {
        try {
            $this->pdo = new PDO("mysql:host=$host;dbname=$database", $user, $pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Database connection failed: " . $e->getMessage());
        }
    }

    public function prepare ($sql) {
        return $this->pdo->prepare($sql);
    }

    public function query ($sql) {
        return $this->pdo->query($sql);
    }
}
?>
