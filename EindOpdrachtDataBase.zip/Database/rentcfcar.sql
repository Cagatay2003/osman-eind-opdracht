CREATE DATABASE rentacar;
 
USE rentacar;
 
CREATE TABLE autos (
  auto_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  automerk VARCHAR(255),
  model VARCHAR(255),
  bouwjaar INT,
  zitplaatsen INT,
  brandstof VARCHAR(255),
  kenteken VARCHAR(255),
  prijs DECIMAL(10,2),
  beschikbaarheid BOOLEAN,
  image VARCHAR(255)
);
 
SELECT * FROM autos;
 
CREATE TABLE klanten (
  klant_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(255),
  password VARCHAR(255),
  voornaam VARCHAR(255),
  achternaam VARCHAR(255),
  geboortedatum DATE,
  gebruikerrol VARCHAR(255),
  adres VARCHAR(255),
  rijbewijsnummer VARCHAR(20),
  telefoonnummer INT,
  email VARCHAR(100)
);
 
SELECT * FROM klanten;

CREATE TABLE verhuringen (
  verhuring_id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
  verhuurdatum DATE, 
  klant_id INT,
  auto_id INT,
  huurperiode INT,
  kosten DECIMAL(10,2),
  FOREIGN KEY (klant_id) REFERENCES klanten(klant_id),
  FOREIGN KEY (auto_id) REFERENCES autos(auto_id)
);
 
SELECT * FROM verhuringen;