<?php
 
class Login
{
    public $pdo;
 
    public function __construct($pdo)
    {
        $this->pdo = $pdo;
    }
 
    public function voegUser($username, $hashPass, $voornaam, $achternaam, $geboortedatum, $gebruikerrol, $adres, $rijbewijsnummer, $telefoonnummer, $email) {
        $hashPass = password_hash($hashPass, PASSWORD_DEFAULT);
   
        $sql = "INSERT INTO klanten VALUES (null, :username, :password, :voornaam, :achternaam, :geboortedatum, :gebruikerrol, :adres, :rijbewijsnummer, :telefoonnummer, :email)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute(['username' => $username, 'password' => $hashPass, 'voornaam' => $voornaam, 'achternaam' => $achternaam, 'geboortedatum' => $geboortedatum, 'gebruikerrol' => $gebruikerrol, 'adres' => $adres, 'rijbewijsnummer' => $rijbewijsnummer, 'telefoonnummer' => $telefoonnummer, 'email' => $email]);
    }
 
    public function verwijderUser(int $klantid) {
    try {
        $sql = "DELETE FROM klanten WHERE klant_id = :klant_id";
        $stmt = $this->pdo->prepare($sql);
        $result = $stmt->execute(['klant_id' => $klantid]);
        return $result;
    } catch (PDOException $e) {
        die("Klant verwijderen mislukt!");
      }
    }
   
    public function selecteerDataBijEmail($email) {
        $stmt = $this->pdo->prepare("SELECT * FROM klanten WHERE email = :email");
        $stmt->execute(['email' => $email]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
 
    public function selecterAlleUser() {
        $stmt = $this->pdo->prepare("SELECT * FROM klanten WHERE gebruikerrol = 'Admin' OR gebruikerrol = 'Klant'");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
 
    public function selecteerMedewerkers() {
        $stmt = $this->pdo->prepare("SELECT * FROM klanten WHERE gebruikerrol = 'Medewerker'");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
 
    public function KrijgGebruikerrolEmail($email) {
        $stmt = $this->pdo->prepare("SELECT gebruikerrol FROM klanten WHERE email = :email");
        $stmt->execute(['email' => $email]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
 
    public function userLoginSysteem($email) {
      $stmt = $this->pdo->prepare("SELECT * FROM klanten WHERE email = ?");
      $stmt->execute([$email]);
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      return $result;
    }
}    
 
?>