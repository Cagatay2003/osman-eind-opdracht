<?php 

class Catalogus {
    public $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    private function validateInput(?string $input) : string {
        if ($input === null) {
            return "";
        } else {

            return htmlspecialchars(trim($input), ENT_QUOTES, "UTF-8");
        }
    }

    public function voegauto($automerk, $model, $bouwjaar, $aantalplaatsen, $brandstof, $kenteken, $prijs, $beschikbaarheid, $image) {
    try {    
        $automerk = $this->validateInput($automerk);
        $model = $this->validateInput($model);
        $bouwjaar = $this->validateInput($bouwjaar);
        $aantalplaatsen = $this->validateInput($aantalplaatsen);
        $brandstof = $this->validateInput($brandstof);
        $kenteken = $this->validateInput($kenteken);
        $prijs = $this->validateInput($prijs);
        $beschikbaarheid = $this->validateInput($beschikbaarheid);
        $image = $this->validateInput($image);

        $sql = "INSERT INTO `catalogus` (`automerk`, `model`, `bouwjaar`, `aantalplaatsen`, `brandstof`, `kenteken`, `prijs`, `beschikbaarheid`, `image`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([$automerk, $model, $bouwjaar, $aantalplaatsen, $brandstof, $kenteken, $prijs, $beschikbaarheid, $image]);
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
    }

    public function editauto ($automerk, $model, $bouwjaar, $aantalplaatsen, $brandstof, $kenteken, $prijs, $beschikbaarheid, $image, $autoid) {
    try {
        $automerk = $this->validateInput($automerk);
        $model = $this->validateInput($model);
        $bouwjaar = $this->validateInput($bouwjaar);
        $aantalplaatsen = $this->validateInput($aantalplaatsen);
        $brandstof = $this->validateInput($brandstof);
        $kenteken = $this->validateInput($kenteken);
        $prijs = $this->validateInput($prijs);
        $beschikbaarheid = $this->validateInput($beschikbaarheid);
        $image = $this->validateInput($image);
        $autoid = $this->validateInput($autoid);

        $stmt = $this->pdo->prepare("UPDATE `autos` SET `automerk` = ?, `model` = ?, `bouwjaar` = ?, `aantalplaatsen` = ?, `brandstof` = ?, `kenteken` = ?, `prijs` = ?, `beschikbaarheid` = ?, `image` = ? WHERE `auto_id` = ?");
        $stmt->execute([$automerk, $model, $bouwjaar, $aantalplaatsen, $brandstof, $kenteken, $prijs, $beschikbaarheid, $image, $autoid]);
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
     }
    }

    public function editautozonderfoto($automerk, $model, $bouwjaar, $aantalplaatsen, $brandstof, $kenteken, $prijs, $beschikbaarheid, $autoid) {
    try {
        $automerk = $this->validateInput($automerk);
        $model = $this->validateInput($model);
        $bouwjaar = $this->validateInput($bouwjaar);
        $aantalplaatsen = $this->validateInput($aantalplaatsen);
        $brandstof = $this->validateInput($brandstof);
        $kenteken = $this->validateInput($kenteken);
        $prijs = $this->validateInput($prijs);
        $beschikbaarheid = $this->validateInput($beschikbaarheid);
        $autoid = $this->validateInput($autoid);
    
            $stmt = $this->pdo->prepare("UPDATE `autos` SET `automerk` = ?, `model` = ?, `bouwjaar` = ?, `aantalplaatsen` = ?, `brandstof` = ?, `kenteken` = ?, `prijs` = ?, `beschikbaarheid` = ?, `image` = ? WHERE `auto_id` = ?");
            $stmt->execute([$automerk, $model, $bouwjaar, $aantalplaatsen, $brandstof, $kenteken, $prijs, $beschikbaarheid, $autoid]);
        } catch (PDOException $e) {
            die("Error: " . $e->getMessage());
         }
    }

    public function deleteauto($autoid) {
    try {
        $stmt = $this->pdo->prepare("DELETE FROM `autos` WHERE `auto_id` = ?");
        $stmt->execute([$autoid]);
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
    }

    public function selecteeralleautos() {
        $sql = "SELECT * FROM `autos` WHERE beschikbaarheid = 1";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function selecteerverwijderdauto() {
        $sql = "SELECT * FROM `autos` WHERE beschikbaarheid = 0";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function selectalleautoadmin() {
        $sql = "SELECT * FROM `autos`";
        $stmt = $this->pdo->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

?>